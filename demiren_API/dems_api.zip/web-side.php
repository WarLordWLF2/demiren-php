<?php

include 'header.php';

// ------------------------------------------- For Website ------------------------------------------- //

class Web_Tools_Functions
{
    // -------- Create Data -------- //
    // Login
    function customer_login($data)
    {
        include "connection.php";

        $sql = "SELECT * FROM tbl_customers
                    WHERE customers_email = :email AND customers_password = :code";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":email", $data["userMail"]);
        $stmt->bindParam(":code", $data["userPass"]);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $rowCount = $stmt->rowCount();
        unset($stmt, $pdo);

        return $rowCount > 0 ? json_encode($result) : 0;
    }

    // Create New Account
    function new_account($data)
    {
        include "connection.php";

        $sql = "INSERT INTO tbl_customers(customer_user_level_id, customers_fname, customers_lname, customers_country, customers_email,
                                             customers_password ,customers_phone, customers_age) 
                VALUES(1, :fname, :lname, :country, :email, :code, :phone, :age)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":fname", $data["fname"]);
        $stmt->bindParam(":lname", $data["lname"]);
        $stmt->bindParam(":country", $data["country"]);
        $stmt->bindParam(":code", $data["password"]);
        $stmt->bindParam(":email", $data["email"]);
        $stmt->bindParam(":phone", $data["phone"]);
        $stmt->bindParam(":age", $data["age"]);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $rowCount = $stmt->rowCount();
        unset($stmt, $pdo);

        return $rowCount > 0 ? json_encode($result) : 0;
    }

    // -------- Read Data -------- //
    // Display only the Current User's Check Ins and Outs
    function display_signins($data)
    {
        include "connection.php";

        $sql = "SELECT checkin_checkout_id, checkin_date, checkin_time, checkout_date, checkout_time, checkin_checkout_status, 
                    reservation_online_downpayment FROM tbl_checkin_checkout 
                WHERE checkin_checkout_customers_id = :cust_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":cust_id", $data[""]);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $rowCount = $stmt->rowCount();

        return $rowCount > 0 ? json_encode($result) : 0;
    }

    // Displays Current Customer Information
    function display_myInfo($data)
    {
        include "connection.php";

        $sql = "SELECT customers_fname, customers_lname, customers_country, customers_email, customers_phone, customers_age FROM tbl_customers
                WHERE customers_id = :cust_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":cust_id", $data[""]);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $rowCount = $stmt->rowCount();

        return $rowCount > 0 ? json_encode($result) : 0;
    }

    // 
    function display_Resv_Txn() {}

    // -------- Update Data -------- //
    // Customer Updates Account
    function update_account($data)
    {
        include "connection.php";

        $sql = "UPDATE tbl_customers SET customers_fname = :fname, customers_lname = :lname, customers_country = :country, customers_email = :email, 
                    customers_phone = :phone, customers_age = :age
                WHERE customers_id = :cust_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":cust_id", $data[""]);
        $stmt->bindParam(":fname", $data[""]);
        $stmt->bindParam(":lname", $data[""]);
        $stmt->bindParam(":country", $data[""]);
        $stmt->bindParam(":email", $data[""]);
        $stmt->bindParam(":phone", $data[""]);
        $stmt->bindParam(":age", $data[""]);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $rowCount = $stmt->rowCount();
        unset($stmt, $pdo);

        return $rowCount > 0 ? json_encode($result) : 0;
    }
}

$web_tools = new Web_Tools_Functions();
$methodType = isset($_POST["method"]) ? $_POST["method"] : 0;
$jsonData = isset($_POST["json"]) ? json_decode($_POST["json"], true) : 0;

switch ($methodType) {
        // Login
    case "submit-login":
        echo $web_tools->customer_login($jsonData);
        break;

        // Create Methods
    case "addUser":
        echo $web_tools->new_account($jsonData);
        break;

        // Read Methods

        // Update Methods
    default:
        return json_encode(["response" => false, "message" => "Request Denied"]);
}
