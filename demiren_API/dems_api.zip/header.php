<?php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Method: GET, POST, PUT, OPTIONS");
header("Access-Control-Allow-Method: Content-Type, Authorization");
